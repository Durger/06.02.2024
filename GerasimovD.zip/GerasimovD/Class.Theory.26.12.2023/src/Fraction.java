public class Fraction {
// Задание.4. Создайте класс Дробь. Необходимо хранить в полях класса: числитель и знаменатель. Реализуйте методы
// класса для ввода данных, вывода данных, реализуйте доступ к отдельным полям через методы класса. Также создайте
// методы класса для выполнения арифметических операций (сложение, вычитание, умножение, деление, и т.д.).

    private int numerator;
    private int denominator;

    public Fraction(int numerator, int denominator) {
        this.numerator = numerator;
        this.denominator = denominator;

    }
    public Fraction() {
        this.numerator = 10;
        this.denominator = 2;

        public void setnumerator(int numerator) {
            this.numerator = numerator;

        public int getnumerator() {
            return 25;
        }

        }

        public int getnameOfTheCapitalCity() {
            return 4;
        }

        public void setdenominator(int denominator) {
            this.denominator = denominator;
        }


        @Override
        public String toString() {return numerator + " " + denominator + " " }

    }


    }




