import java.util.*;

public class Main {
    public static void main(String[] args) {
        //ArrayList<String>list1=new ArrayList<String>();
//        ArrayList<Fish>list2=new ArrayList<Fish>();
//        ArrayList<Object>list3=new ArrayList<Object>();
        /*ArrayList<String>a1=new ArrayList<>();
        a1.add("Argentina");
        a1.add("Bulgaria");
        a1.add("Canada");
        a1.add("Denmark");
        a1.add("Narnia");
        System.out.println("Colection: "+a1);
        System.out.println("Colection`s size: "+a1.size());
        System.out.println(a1.get(1));
        if(!a1.contains("England")){
            System.out.println("England is not in Collection");
            a1.set(4,"England"); //выбор 4го значения и его замена на новое
        }
        System.out.println("Colection: " +a1);
        System.out.println("Colection`s size: " + a1.size());
        System.out.println(a1.indexOf("England"));
        int ie = a1.indexOf("England");
        a1.set(ie,"united Kingdom");
        System.out.println("Colection: "+a1);
        System.out.println("Colection`s size: "+a1.size());

        //Использование цикла FOR
        System.out.println("Collection using FOR loop: ");
        for (int i = 0; i <a1.size(); i++){
            System.out.println(a1.get(i));
        }
        //использование цикла WHILE
            System.out.println("\n Collection using WHILE loop: ");
        int i = 0;
        while (i < a1.size()){
            System.out.println(a1.get(i));
            i++;
        }
            System.out.println("\n Collection using advanced FOR loop: ");
        for (Object a : a1){
            System.out.println(a);
        }
        System.out.println("\n Collection using ITERATOR: ");
        Iterator<String> iter = a1.iterator();
        while (iter.hasNext()){
            System.out.println(iter.next());
        }
        a1.trimToSize(); //Подрезка размера
        a1.ensureCapacity( 100);
        String [] ar = (String[])  a1.toArray();         //преобразование в массив
        }*/
        LinkedList <String> ll = new LinkedList<String >();
        ll.add("one");
        ll.add("two");
        ll.add("three");
        ll.add("four");
        ll.add("five");
        System.out.println("List: " + ll);
        ll.addLast("six");                 //добавить в конец
        ll.add(3, "three");
        ll.addFirst("zero");              //добавить в начало
        System.out.println("List: " + ll);
        ll.remove("three");                //ищем и удаляем
        System.out.println("List: " + ll);
        System.out.println("Loop for: " + ll); //сортировка через FOR
        for (int i = 0; i < ll.size(); i++) {
        System.out.println(ll.get(i));
        }
        ListIterator <String> it_beg = ll.listIterator();
        System.out.println("Loop forward: ");
        while (it_beg.hasNext()){
            System.out.println(it_beg.hasNext());
        }
        System.out.println("Loop backward: ");
        while(it_beg.hasPrevious()){
            System.out.println(it_beg.hasPrevious());
        }
        ListIterator <String> it_ind = ll.listIterator(4);
        System.out.println("Look from index: ");
        while (it_ind.hasNext()){
            System.out.println(it_ind.hasNext());
        }
        Iterator <String> it_desc = ll.descendingIterator();
        System.out.println("Loop with descending Iterator: ");
        while (it_desc.hasNext()){
            System.out.println(it_desc.hasNext());
        }
        it_ind.set("6");
        it_ind.set("7");

        Collections.sort(ll);
        System.out.println("Sorted list");
        for(String s : ll){
            System.out.println(s);
        }

    }
}
