import java.util.*;

public class Main {
    public static void main(String[] args) {

//Задание.
// HashSet:
//Удаление дублирующихся элементов из коллекции.
//Проверка наличия элемента в коллекции.
//Использование в качестве ключей в HashMap для быстрого доступа к значениям.
//Реализация алгоритмов, требующих проверки уникальности элементов.

        /*Set<String> peopleHashSet = new HashSet();
        peopleHashSet.add("Jack");
        peopleHashSet.add("John");
        peopleHashSet.add("Deny");
        peopleHashSet.add("Michail");
        peopleHashSet.add("Rob");

        System.out.println("People: " + peopleHashSet);
        System.out.println("People: " + peopleHashSet.contains("Rob"));
        peopleHashSet.remove("Deny");

        System.out.println("People: " + peopleHashSet.contains("Deny"));
        System.out.println("People: " + peopleHashSet);*/

//LinkedHashSet:
//Сохранение порядка добавления элементов.
//Удаление дублирующихся элементов из коллекции с сохранением порядка.
//Использование в качестве ключей в LinkedHashMap для сохранения порядка доступа к значениям.

       /* Set<String> peopleLinkedHashSet = new LinkedHashSet();
        peopleLinkedHashSet.add("Jack");
        peopleLinkedHashSet.add("John");
        peopleLinkedHashSet.add("Deny");
        peopleLinkedHashSet.add("Michail");
        peopleLinkedHashSet.add("Rob");
        peopleLinkedHashSet.add("Rob");
        System.out.println("People: " + peopleLinkedHashSet);
        peopleLinkedHashSet.remove("Michail");
        System.out.println("People: " + peopleLinkedHashSet);*/

//TreeSet:
//Сортировка элементов в естественном порядке или с использованием компаратора.
//Получение наибольшего и наименьшего элементов из коллекции.
//Поиск элементов в отсортированной коллекции с использованием методов like ceiling(), floor(), higher(), lower().

        Set<String> peopleSet = new TreeSet<>();
        peopleSet.add("Jack");
        peopleSet.add("John");
        peopleSet.add("Deny");
        peopleSet.add("Michail");
        peopleSet.add("Rob");
        peopleSet.add("Rob");
        System.out.print(" People: " + peopleSet);

        //Получение наибольшего и наименьшего элементов из коллекции.
        System.out.println();
        System.out.println(((TreeSet<String>) peopleSet).first());
        System.out.println(((TreeSet<String>) peopleSet).last());

//        Iterator iterator = peopleSet.iterator();
//        while (iterator.hasNext()) {
//            System.out.println(iterator.next() + " ");
//        }

        //Поиск элементов в отсортированной коллекции с использованием методов like ceiling(), floor(), higher(), lower().


    }
}