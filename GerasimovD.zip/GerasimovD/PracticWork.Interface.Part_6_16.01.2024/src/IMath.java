public interface IMath {

    // - int Max() - возвращает максимум,
    void  Max();

    // - int Min() - возвращает минимум,
    void  Min();

    // - int Avg() - возвращает среднеарифметическое.
    void  Avg();

}
